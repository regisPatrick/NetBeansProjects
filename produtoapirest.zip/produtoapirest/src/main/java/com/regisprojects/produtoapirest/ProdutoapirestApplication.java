package com.regisprojects.produtoapirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdutoapirestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdutoapirestApplication.class, args);
	}

}
