package com.spring.agendalive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendaliveApplicationTests {

	@Test
	void contextLoads() {
	}

}
