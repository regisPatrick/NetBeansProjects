package com.regisprojects.apigooglepesquisa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGooglePesquisaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGooglePesquisaApplication.class, args);
	}

}
