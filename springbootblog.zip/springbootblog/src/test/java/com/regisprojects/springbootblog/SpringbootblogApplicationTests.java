package com.regisprojects.springbootblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootblogApplicationTests {

	@Test
	void contextLoads() {
	}

}
