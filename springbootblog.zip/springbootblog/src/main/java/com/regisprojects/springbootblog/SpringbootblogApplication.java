package com.regisprojects.springbootblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootblogApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootblogApplication.class, args);
	}

}
