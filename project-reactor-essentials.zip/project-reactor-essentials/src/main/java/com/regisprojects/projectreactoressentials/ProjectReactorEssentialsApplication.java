package com.regisprojects.projectreactoressentials;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectReactorEssentialsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectReactorEssentialsApplication.class, args);
	}

}
