package br.com.regisprojects.cursospringbootessentials;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursospringbootessentialsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursospringbootessentialsApplication.class, args);
	}

}
