package com.regisprojects.apipesquisagoogle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPesquisaGoogleApplicationTests {

	@Test
	void contextLoads() {
	}

}
