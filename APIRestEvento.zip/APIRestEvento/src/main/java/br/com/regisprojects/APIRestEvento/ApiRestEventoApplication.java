package br.com.regisprojects.APIRestEvento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestEventoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestEventoApplication.class, args);
	}

}
