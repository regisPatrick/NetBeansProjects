package br.com.regisprojects.appevento.appevento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppeventoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppeventoApplication.class, args);
	}

}
