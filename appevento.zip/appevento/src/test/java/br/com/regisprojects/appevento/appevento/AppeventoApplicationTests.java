package br.com.regisprojects.appevento.appevento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppeventoApplicationTests {

	@Test
	void contextLoads() {
	}

}
