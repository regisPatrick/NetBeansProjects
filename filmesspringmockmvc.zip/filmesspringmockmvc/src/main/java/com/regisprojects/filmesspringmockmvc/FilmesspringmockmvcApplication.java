package com.regisprojects.filmesspringmockmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmesspringmockmvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmesspringmockmvcApplication.class, args);
	}

}
