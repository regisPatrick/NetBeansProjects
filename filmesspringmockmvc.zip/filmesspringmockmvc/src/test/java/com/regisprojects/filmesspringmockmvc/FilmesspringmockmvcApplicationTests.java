package com.regisprojects.filmesspringmockmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmesspringmockmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
