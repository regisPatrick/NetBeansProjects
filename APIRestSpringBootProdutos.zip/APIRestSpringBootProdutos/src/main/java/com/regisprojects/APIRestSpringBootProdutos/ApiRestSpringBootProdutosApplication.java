package com.regisprojects.APIRestSpringBootProdutos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestSpringBootProdutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestSpringBootProdutosApplication.class, args);
	}

}
