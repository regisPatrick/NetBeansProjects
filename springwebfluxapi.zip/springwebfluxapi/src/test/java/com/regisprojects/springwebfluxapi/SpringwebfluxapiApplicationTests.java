package com.regisprojects.springwebfluxapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwebfluxapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
