package com.regisprojects.springwebfluxapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwebfluxapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwebfluxapiApplication.class, args);
	}

}
