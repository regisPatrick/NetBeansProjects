package com.sispetshop.sispetshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SispetshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
