package com.sispetshop.sispetshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SispetshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SispetshopApplication.class, args);
	}

}
