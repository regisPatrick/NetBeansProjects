package com.produtos.APIRestProdutos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
