package com.regisprojects.webserviceeventoapirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebserviceeventoapirestApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebserviceeventoapirestApplication.class, args);
	}

}
